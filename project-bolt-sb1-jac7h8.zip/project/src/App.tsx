import React from 'react';
import { Navigation } from './components/Navigation';
import { MenuSection } from './components/menu/MenuSection';
import { ReservationForm } from './components/reservation/ReservationForm';
import { OrderTracker } from './components/order/OrderTracker';
import { FAQ } from './components/FAQ';
import { MenuItem } from './types';

const menuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Crispy Calamari',
    description: 'Tender calamari rings served with zesty marinara sauce',
    price: 12.99,
    category: 'starters',
    image: 'https://images.unsplash.com/photo-1604909052743-94e838986d24?auto=format&fit=crop&w=800',
    dietary: {
      glutenFree: false,
    },
  },
  {
    id: '2',
    name: 'Grilled Salmon',
    description: 'Fresh Atlantic salmon with seasonal vegetables',
    price: 26.99,
    category: 'main',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800',
    dietary: {
      glutenFree: true,
    },
  },
  {
    id: '3',
    name: 'Chocolate Lava Cake',
    description: 'Warm chocolate cake with a molten center',
    price: 8.99,
    category: 'desserts',
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800',
    dietary: {
      vegetarian: true,
    },
  },
];

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <section id="menu" className="mb-16">
          <h1 className="text-4xl font-bold text-center mb-12">Our Menu</h1>
          <MenuSection
            title="Featured Items"
            items={menuItems}
          />
        </section>

        <section id="reservations" className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Make a Reservation</h2>
          <ReservationForm />
        </section>

        <section id="order-tracking" className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Track Your Order</h2>
          <OrderTracker orderId="123456" />
        </section>

        <section id="faq" className="mb-16">
          <FAQ />
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <p>123 Gourmet Street</p>
              <p>Foodie District, City 12345</p>
              <p>Phone: (555) 123-4567</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Hours</h3>
              <p>Monday - Sunday</p>
              <p>11:00 AM - 10:00 PM</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
              <div className="space-x-4">
                <a href="#" className="hover:text-gray-300">Facebook</a>
                <a href="#" className="hover:text-gray-300">Instagram</a>
                <a href="#" className="hover:text-gray-300">Twitter</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;