import React from 'react';

const faqs = [
  {
    question: 'What are your opening hours?',
    answer: 'We are open Monday to Sunday, 11:00 AM to 10:00 PM.',
  },
  {
    question: 'Do you offer vegetarian options?',
    answer: 'Yes, we have a wide variety of vegetarian and vegan dishes. All items are clearly marked on our menu.',
  },
  {
    question: 'Where are you located?',
    answer: '123 Gourmet Street, Foodie District, City, 12345',
  },
  {
    question: 'Do you take reservations?',
    answer: 'Yes, we accept reservations through our website or by phone. We recommend booking in advance for weekends.',
  },
  {
    question: 'Is there parking available?',
    answer: 'Yes, we have free parking available for our customers in the adjacent lot.',
  },
];

export function FAQ() {
  return (
    <div className="max-w-3xl mx-auto py-12 px-4">
      <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
      <div className="space-y-6">
        {faqs.map((faq, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
            <p className="text-gray-600">{faq.answer}</p>
          </div>
        ))}
      </div>
    </div>
  );
}