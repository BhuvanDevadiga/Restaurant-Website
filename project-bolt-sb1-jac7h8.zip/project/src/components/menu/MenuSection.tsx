import React from 'react';
import { MenuItem } from '../../types';

interface MenuSectionProps {
  title: string;
  items: MenuItem[];
}

export function MenuSection({ title, items }: MenuSectionProps) {
  return (
    <section className="py-8">
      <h2 className="text-2xl font-bold mb-6">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item) => (
          <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-semibold">{item.name}</h3>
                <span className="text-green-600 font-medium">${item.price}</span>
              </div>
              <p className="text-gray-600 text-sm mb-3">{item.description}</p>
              {item.dietary && (
                <div className="flex gap-2">
                  {item.dietary.vegetarian && (
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                      Vegetarian
                    </span>
                  )}
                  {item.dietary.vegan && (
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                      Vegan
                    </span>
                  )}
                  {item.dietary.glutenFree && (
                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">
                      Gluten-Free
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}