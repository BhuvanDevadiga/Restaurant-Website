import React from 'react';
import { OrderStatus } from '../../types';
import { CheckCircle, Clock, Truck } from 'lucide-react';

interface OrderTrackerProps {
  orderId: string;
}

export function OrderTracker({ orderId }: OrderTrackerProps) {
  const [orderStatus, setOrderStatus] = React.useState<OrderStatus>({
    id: orderId,
    status: 'received',
    estimatedDelivery: '30-45 minutes',
  });

  const statusSteps = [
    { key: 'received', label: 'Order Received', icon: CheckCircle },
    { key: 'preparing', label: 'Preparing', icon: Clock },
    { key: 'delivering', label: 'Out for Delivery', icon: Truck },
    { key: 'delivered', label: 'Delivered', icon: CheckCircle },
  ];

  const currentStep = statusSteps.findIndex((step) => step.key === orderStatus.status);

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Order Status</h2>
      <div className="relative">
        {statusSteps.map((step, index) => {
          const Icon = step.icon;
          const isActive = index <= currentStep;
          
          return (
            <div key={step.key} className="flex items-center mb-8">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                isActive ? 'bg-green-500' : 'bg-gray-200'
              }`}>
                <Icon className={`w-6 h-6 ${isActive ? 'text-white' : 'text-gray-500'}`} />
              </div>
              <div className="ml-4">
                <p className={`font-medium ${isActive ? 'text-green-500' : 'text-gray-500'}`}>
                  {step.label}
                </p>
                {index === currentStep && orderStatus.estimatedDelivery && (
                  <p className="text-sm text-gray-500">
                    Estimated time: {orderStatus.estimatedDelivery}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}