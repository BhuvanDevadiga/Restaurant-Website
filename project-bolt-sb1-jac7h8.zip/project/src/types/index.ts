export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'starters' | 'main' | 'beverages' | 'desserts';
  image: string;
  dietary?: {
    vegetarian?: boolean;
    vegan?: boolean;
    glutenFree?: boolean;
  };
}

export interface TableReservation {
  date: string;
  time: string;
  guests: number;
  name: string;
  email: string;
  phone: string;
}

export interface OrderStatus {
  id: string;
  status: 'received' | 'preparing' | 'delivering' | 'delivered';
  estimatedDelivery?: string;
}